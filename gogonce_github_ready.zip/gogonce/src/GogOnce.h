// Author: Robert Gogol <robert.gogol@gmail.com>
#ifndef GOGONCE_H
#define GOGONCE_H

#include <Arduino.h>

class GogOnce {
public:
    GogOnce(uint8_t pin, unsigned long debounceDelay = 5);
    void begin();
    int update();  // Zwraca wartosc tylko gdy nastąpiła zmiana, inaczej nic

private:
    uint8_t _pin;
    unsigned long _debounceDelay;
    int _lastReading;
    int _stableState;
    unsigned long _lastDebounceTime;
};

#endif
