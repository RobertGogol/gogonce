// Author: Robert Gogol <robert.gogol@gmail.com>
#include "GogOnce.h"

GogOnce::GogOnce(uint8_t pin, unsigned long debounceDelay)
    : _pin(pin),
      _debounceDelay(debounceDelay),
      _lastReading(HIGH),
      _stableState(HIGH),
      _lastDebounceTime(0) {}

void GogOnce::begin() {
    pinMode(_pin, INPUT_PULLUP);
}

int GogOnce::update() {
    int currentReading = digitalRead(_pin);

    if (currentReading != _lastReading) {
        _lastDebounceTime = millis();
    }

    _lastReading = currentReading;

    if ((millis() - _lastDebounceTime) > _debounceDelay) {
        if (currentReading != _stableState) {
            _stableState = currentReading;

            if (_stableState == LOW) {
                return _pin * 10;
            } else {
                return _pin;
            }
        }
    }

    return -1; // brak zmiany
}
