# gogonce

Biblioteka Arduino do wykrywania zmian stanu na pinie wejściowym (`INPUT_PULLUP`) z eliminacją drgań styków (debounce). Zwraca liczbę zależną od numeru pinu i poziomu logicznego.

## Zasada działania

- Jeśli na pinie jest **stan wysoki** → zwraca numer pinu (np. `4`)
- Jeśli na pinie jest **stan niski** → zwraca numer pinu × 10 (np. `40`)
- Jeśli nie było zmiany stanu → nie zwraca nic (`-1`)

## Przykład

```cpp
GogOnce input4(4);
...
int v = input4.update();
if (v != -1) {
    Serial.println(v);
}
```

## Kompatybilność

- Arduino Uno
- Arduino Leonardo
